from xolpanel import *

@bot.on(events.NewMessage(pattern=r"(?:.start|/start)$"))
@bot.on(events.CallbackQuery(data=b'/start'))
async def menu(event):
	inline = [
[Button.inline(" PANEL CREATE ACCOUNT ","menu"),
Button.inline(" SETTING MENU ","setting")],
[Button.url(" CHANNEL ","https://t.me/fv_storeid"),
Button.url(" WHATSAPP ","https://wa.me/6283160098834")]]
	sender = await event.get_sender()
	val = valid(str(sender.id))
	if val == "false":
		try:
			await event.answer("Akses Ditolak", alert=True)
		except:
			await event.reply("Akses Ditolak")
	elif val == "true":
		msg = f"""
━━━━━━━━━━━━━━━━
⟨ 👨‍💻Admin Panel Menu ⟩
━━━━━━━━━━━━━━━━
» 🤖Bot Version: `v3.0`
» 🤖Bot By: `@fv_stores`

━━━━━━━━━━━━━━━━
"""
		x = await event.edit(msg,buttons=inline)
		if not x:
			await event.reply(msg,buttons=inline)